<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2014-04-21 09:15:36 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:16:15 --> Fatal Error - Class 'OrmModel' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:17:32 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 5
ERROR - 2014-04-21 09:18:04 --> Fatal Error - Call to undefined method Model_User::find() in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 31
ERROR - 2014-04-21 09:20:31 --> Fatal Error - Call to undefined method Model_User::find_all() in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 31
ERROR - 2014-04-21 09:25:03 --> Fatal Error - Class 'ORM\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:54 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:56 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:57 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:57 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:57 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:57 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:57 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:58 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:58 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:58 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:58 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:58 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:58 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:59 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:59 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:59 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:59 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 09:26:59 --> Fatal Error - Class 'Orm\Model' not found in /Users/hoaqt/Sites/fuel/app/classes/model/user.php on line 4
ERROR - 2014-04-21 10:09:01 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be an array, string given, called in /Users/hoaqt/Sites/fuel/packages/orm/classes/query.php on line 566 and defined in /Users/hoaqt/Sites/fuel/packages/orm/classes/query.php on line 553
ERROR - 2014-04-21 10:10:41 --> Error - SQLSTATE[HY000] [2002] Can't connect to local MySQL server through socket '/Applications/XAMPP/xamppfiles/var/mysql/mysql.sock' (61) in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 100
ERROR - 2014-04-21 10:12:09 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.created_at' in 'field list' with query: "SELECT `t0`.`iduser` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`created_at` AS `t0_c3`, `t0`.`updated_at` AS `t0_c4`, `t0`.`id` AS `t0_c5` FROM `user` AS `t0`" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 10:14:15 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.id' in 'field list' with query: "SELECT `t0`.`iduser` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `user` AS `t0`" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 10:16:20 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.id' in 'field list' with query: "SELECT `t0`.`iduser` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `user` AS `t0`" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 10:20:31 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.id' in 'field list' with query: "SELECT `t0`.`iduser` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `user` AS `t0`" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 10:20:39 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.id' in 'field list' with query: "SELECT `t0`.`iduser` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `user` AS `t0`" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 10:23:00 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.id' in 'field list' with query: "SELECT `t0`.`iduser` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `user` AS `t0` WHERE `t0`.`id` = 1 LIMIT 1" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 10:27:15 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.id' in 'field list' with query: "SELECT `t0`.`iduser` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `user` AS `t0` WHERE `t0`.`id` = 1 LIMIT 1" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 10:27:19 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.id' in 'field list' with query: "SELECT `t0`.`iduser` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `user` AS `t0` WHERE `t0`.`id` = 1 LIMIT 1" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 10:27:22 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.id' in 'field list' with query: "SELECT `t0`.`iduser` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `user` AS `t0` WHERE `t0`.`id` = 1 LIMIT 1" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 10:28:04 --> Notice - Use of undefined constant all - assumed 'all' in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 31
ERROR - 2014-04-21 10:28:27 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.id' in 'field list' with query: "SELECT `t0`.`iduser` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `user` AS `t0`" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 10:37:17 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.id' in 'field list' with query: "SELECT `t0`.`iduser` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `user` AS `t0`" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 10:40:34 --> Notice - Undefined offset: 0 in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 32
ERROR - 2014-04-21 10:42:28 --> Fatal Error - Call to a member function as_array() on a non-object in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 32
ERROR - 2014-04-21 10:57:36 --> Fatal Error - Call to undefined function vardump() in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 32
ERROR - 2014-04-21 11:00:14 --> Notice - Undefined offset: 0 in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 32
ERROR - 2014-04-21 11:03:22 --> Notice - Trying to get property of non-object in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 31
ERROR - 2014-04-21 11:03:50 --> Error - Property "data" not found for Model_User. in /Users/hoaqt/Sites/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-04-21 11:04:16 --> Notice - Undefined offset: 0 in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 31
ERROR - 2014-04-21 11:06:34 --> Notice - Trying to get property of non-object in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 32
ERROR - 2014-04-21 11:31:24 --> Notice - Undefined index: 1 in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 37
ERROR - 2014-04-21 11:32:13 --> Runtime Recoverable error - Object of class Model_User could not be converted to string in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 41
ERROR - 2014-04-21 11:33:54 --> Runtime Recoverable error - Object of class Model_User could not be converted to string in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 40
ERROR - 2014-04-21 14:51:32 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'username' cannot be null with query: "INSERT INTO `user` (`username`, `password`) VALUES (null, null)" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 14:52:43 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'username' cannot be null with query: "INSERT INTO `user` (`username`, `password`) VALUES (null, null)" in /Users/hoaqt/Sites/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-04-21 14:57:49 --> Fatal Error - Undefined class constant 'get' in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 66
ERROR - 2014-04-21 15:07:25 --> Notice - Use of undefined constant pwd - assumed 'pwd' in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 68
ERROR - 2014-04-21 16:19:31 --> Notice - Undefined variable: STATUS_OK in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 37
ERROR - 2014-04-21 16:19:42 --> Notice - Undefined variable: STATUS_OK in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 37
ERROR - 2014-04-21 16:19:44 --> Notice - Undefined variable: STATUS_OK in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 37
ERROR - 2014-04-21 16:19:44 --> Notice - Undefined variable: STATUS_OK in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 37
ERROR - 2014-04-21 16:51:56 --> Notice - Undefined variable: array in /Users/hoaqt/Sites/fuel/app/classes/controller/userapi.php on line 70
