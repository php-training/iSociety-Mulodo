<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2013-09-21 18:29:38 --> Parsing Error - syntax error, unexpected ''type'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' in /data/www/fuelphp/1.7/develop/fuel/core/tests/pagination.php on line 243
