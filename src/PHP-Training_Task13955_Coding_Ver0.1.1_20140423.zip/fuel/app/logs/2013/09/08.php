<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2013-09-08 14:50:23 --> Parsing Error - syntax error, unexpected ''give_me'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' in /data/www/fuelphp/1.7/develop/fuel/core/tests/arr.php on line 358
