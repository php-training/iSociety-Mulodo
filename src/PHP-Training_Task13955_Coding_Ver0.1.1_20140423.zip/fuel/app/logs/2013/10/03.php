<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2013-10-03 15:08:02 --> Fatal Error - Call to undefined function Debug::dump() in /data/www/fuelphp/1.7/develop/fuel/core/base.php on line 462
